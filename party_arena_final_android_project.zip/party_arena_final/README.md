# Party Arena — Android app source project

This is an Android Studio project for an offline-first, same-device Party Arena app. The game UI is bundled locally in `app/src/main/assets/index.html`; it does not need a web server or internet connection to launch.

## Included
- Android launcher activity using a local WebView (fullscreen, landscape, hardware accelerated).
- 20 mini-game modes in the bundled game interface.
- 2–4 player same-device play, with player-count-specific seating layout.
- Match setup with 1–10 rounds and selection limited to the number of rounds.
- Fixed Start Match dock beside the game-selection flow.
- Hidden Rock Paper Scissors choices until all players lock in.
- Cumulative scoring and final leaderboard.

## Build an installable APK
1. Install Android Studio on a computer.
2. Open this project folder (`party_arena_final`) in Android Studio.
3. Install Android SDK Platform 35 and a compatible Android Gradle Plugin/Gradle version when prompted.
4. Let Gradle sync, then choose **Build > Build APK(s)**.
5. Android Studio will show the generated APK path. Install it on the phone and test touch/layout behaviour.

## Current limitations
- This environment does not contain Android SDK/Gradle, so no APK could be compiled or tested here. This is the Android Studio source project, not an APK.
- Real-device testing is still required.
- Online room-code play and separate-phone Wi-Fi/hotspot/Bluetooth multiplayer are not implemented.
- Some mini-games are casual prototype mechanics; the included smoke tests are not exhaustive QA.
